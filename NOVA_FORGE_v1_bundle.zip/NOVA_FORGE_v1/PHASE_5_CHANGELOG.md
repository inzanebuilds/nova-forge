# Phase 5 changelog — Isolated web build worker foundation

## Added
- Optional `server/build-worker.js` Docker-backed build queue for static HTML and Node web projects.
- `POST /api/builds`, `GET /api/builds`, job detail/log endpoints, cancellation, terminal-job removal, and downloadable ZIP artifacts.
- Source path traversal checks, restricted secret/config paths, per-file/total source limits, output file/size limits, bounded queue/history, and build timeouts.
- Docker resource/security flags: 512 MB memory, 1 CPU, 128 process limit, all Linux capabilities dropped, no-new-privileges, read-only container root, project-only writable mount, and network disabled by default.
- Build & Publish UI controls to submit a project to the configured server worker, refresh job status, inspect logs, cancel, remove and download artifacts.
- Worker configuration in `server/.env.example`; worker remains disabled by default.

## Safety and limitations
- The build worker requires Docker Engine/CLI and is not enabled unless `NOVA_BUILD_WORKER_ENABLED=true` is set on the server.
- Project build scripts execute as untrusted code inside the container. Network access remains disabled unless separately opted in via `NOVA_BUILD_ALLOW_NETWORK=true`.
- The API is not authenticated and must not be exposed as a public multi-user service. Use only on a trusted private server until authentication, tenant isolation, stronger quotas, and deployment hardening are implemented.
- Jobs and artifacts are held in server memory and disappear when the server restarts.
- The worker handles web project builds/packaging only. No Android APK/AAB compilation, public hosting, or deployment was added.

## Verification
- `npm run check --prefix server` passes, including API smoke tests, build input safety tests, ZIP structure checks, and Phase 4 preflight tests.
- Node syntax checks pass for server and client scripts.
- Docker end-to-end execution is **not verified** because Docker is unavailable in this environment. Browser interaction and Android device tests remain pending.
