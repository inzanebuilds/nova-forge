# Phase 6 changelog — phone-first hosted workspace foundation

## Added
- `render.yaml`: managed Node web-service blueprint with a generated workspace token, health check, and Docker worker disabled by default.
- `DEPLOY_FROM_PHONE.md`: mobile-browser-oriented deployment and connection instructions, with explicit caveats about repository/account setup and free-tier terms.
- Optional bearer-token authentication for API routes. `/api/health` stays public for health checks and reports `authRequired`; other API routes return 401 when a token is configured and missing/incorrect.
- CORS preflight now permits the `Authorization` header.
- NOVA FORGE AI Core has a workspace-token field and session-only token handling. API requests use the token without persisting it with project settings.
- A safe static-site packager that creates downloadable ZIP artifacts without Docker and without executing project code.
- Clear separation between static ZIP packaging and optional container builds. Projects requiring npm scripts are rejected when container builds are disabled.
- Updated README, implementation blueprint, PWA cache version, and Android WebView asset.

## Verification boundaries
- This is a deployment-ready starter, not a live deployment. No public URL, hosting account, or provider credentials were created by this change.
- Static job metadata/artifacts remain in memory; host restarts can clear them.
- The hosted template does not enable Docker, compile Android APKs, publish websites, or configure a language model.
