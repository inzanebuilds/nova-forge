# NOVA FORGE Phase 3 — Change log

## Implemented
- Optional Node.js API server with a static PWA host and `/api/health`, `/api/chat`, and `/api/plan` endpoints.
- No third-party npm dependencies; Node.js 20+ is required.
- Local fallback planning/chat works without an API key or model. Responses explicitly label this as a local planning fallback, not a language model.
- Optional OpenAI-compatible chat-completions provider configured with server-side environment variables. Credentials are not collected or stored in the browser UI.
- AI Core server URL field, connection check, server-first chat, local fallback on connection failure, plan drafting, local plan history, explicit plan approval, and transfer of a reviewed plan to the Create Project form.
- Plan warnings for high-risk items such as publishing, authentication, Android permissions, and payments. Approval only approves the plan; it does not execute code or publish anything.
- Basic API protections: request body size cap, per-IP rate limit, origin allowlist/same-origin checks, safe static-file path handling, and response security headers.
- PWA manifest and service-worker paths corrected for the server-root web app.
- Settings updates now preserve the optional AI server URL.

## Tests performed
- Node syntax checks passed for the client JavaScript and server.
- Automated smoke tests passed for static page serving, health endpoint, local plan generation, local chat fallback, invalid plan request rejection, CORS origin rejection/acceptance, and unique HTML IDs.
- The Phase 2 ZIP writer produced an archive accepted by `unzip -t`; test entries extracted correctly.
- Full Chromium browser interaction test remains inconclusive: Chromium stalled in this environment before returning a DOM. IndexedDB and ZIP-import behavior still need testing in a real Android browser.

## Important limits
- This is not a production-secure public server. It has no user authentication, TLS termination, persistent job queue, container isolation, or deployment worker. Keep it bound to localhost for first run. Before remote exposure, put it behind HTTPS and authentication, set an exact `NOVA_ALLOWED_ORIGINS` list, firewall it, and review the security model.
- A model is not bundled. Without `NOVA_MODEL_BASE_URL`, chat and plans use deterministic local fallback logic. With a model configured, the server makes requests to an OpenAI-compatible `/chat/completions` endpoint.
- A plan is not code execution. No actual autonomous coding, compilation, hosting, APK generation, or publishing was added in this phase.
- ZIP import remains text-oriented; arbitrary binary assets and complete project dependency installation are not supported.
