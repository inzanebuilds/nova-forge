# NOVA FORGE Phase 2 — Change log

## Added
- IndexedDB storage with legacy localStorage migration and fallback.
- Folder creation, project assignment, and folder filtering.
- Soft delete to local trash and restore / empty trash actions.
- Checkpoint creation, bounded version history, version restore, and undo to the previous saved snapshot.
- ZIP export using valid store-method ZIP entries.
- ZIP import for text-oriented archives: stored entries and DEFLATE entries when `DecompressionStream('deflate-raw')` is supported.
- Import limits and path traversal checks for ZIP files.
- Updated PWA service-worker cache version and Android WebView bundled page.

## Validation performed
- JavaScript syntax check with Node.js: passed.
- Static UI check: no duplicate HTML IDs found; all `onclick` handlers map to defined functions.
- Browser execution: not conclusively validated in this environment; Chromium headless did not complete its DOM dump within the allotted time.

## Known gaps
- ZIP handling is text-oriented and does not preserve arbitrary binary assets.
- No visual diff interface yet; version snapshots store complete project file maps.
- IndexedDB and ZIP import/export should be tested in the target Android browser.
- No cloud sync, encryption, actual AI model, real build worker, hosting, or APK compilation is included in this phase.

## Additional verification during Phase 3
- The Phase 2 ZIP writer was executed directly in Node.js; the generated two-entry archive passed `unzip -t`, and an entry's contents were extracted successfully.
- Full repeatable checks are recorded in `TEST_REPORT.md`. IndexedDB behavior, ZIP import in the browser, and Android device behavior remain unverified because the headless browser run stalled.
