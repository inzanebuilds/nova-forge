# NOVA FORGE — Phase 4 changelog

## Implemented
- Added local static project preflight checks in Build & Publish.
- Checks for a missing HTML entry point, missing document title or mobile viewport, missing local file references, images without `alt`, use of `eval`, explicit HTTP links, large files, TODO/FIXME markers, and common secret-like assignments.
- Checks inspect saved project text only; they do not execute project code. Entry-point checks are tailored to browser-oriented project types so non-web projects are not automatically flagged for lacking HTML.
- Added persistent local job history with separate preflight and demo-job labels, timestamps, summaries, expandable logs, rerun actions, individual removal, and confirmed history clearing.
- Added explicit preflight status: Passed, Passed with warnings, or Needs fixes.
- Kept demo build jobs clearly marked as simulation; no APK compile, container, deployment, or remote worker is claimed.
- Synchronized the standalone HTML, PWA entry point, and Android WebView asset.
- Updated the service-worker cache version to invalidate the older Phase 3 shell.
- Added a repeatable smoke test for the preflight checker.

## Verification
- `npm run check --prefix server` passes, including API smoke tests, client JavaScript syntax and UI wiring checks, ZIP writer validation, and preflight validator tests.
- `node tests/zip-smoke.js` passes independently.
- Chromium headless execution still times out in this environment; actual browser interaction and Android device testing remain unverified.

## Limitations
- This is a local static checker, not a compiler or security auditor. It can miss issues and can report false positives.
- No code is executed during preflight.
- Build queue and history are stored in the current browser/device. There is no remote authenticated worker, real build artifact, publishing service, or cross-device sync.
