# NOVA FORGE — Implementation Blueprint
**Version:** 1.0 · based on all 50 interview answers

## Product goal
A personal, free-first, local-first AI development studio for Android and web. Turn plain-English ideas into websites, web apps, Android APKs, mobile/browser games, desktop apps, APIs, backends and full-stack projects. No mandatory account for local use; projects private by default; public release requires approval.

## Experience and design
- Cinematic black splash, centered glowing NOVA FORGE logo, purple/cyan light, restrained starfield, progress indicator and reduced-motion support.
- Main screen: welcome, create project, project-type chooser, prompt box, recent projects and templates.
- Responsive glass/neon interface; mobile bottom navigation, desktop sidebar, customizable accent themes and panels.
- Project cards/list/grid, search, sorting, favorites, folders, activity, milestones, timestamps and build status.
- Project studio with AI chat, file tree/editor, live web preview, visual editor, logs, settings and build/publish workflow.

## Selected capabilities
- Prompt-based project creation; image/design uploads; import existing code and ZIPs.
- Blueprint and approval before complex changes; automatic file generation; dependency detection/setup where a trusted runtime exists.
- Preview changes, file-by-file approval, checkpoints, undo/version restore, tests, retries and plain-English errors.
- Independent projects, parallel agents, background remote jobs, cancel/pause/resume when supported, completion notices and recovery.
- Languages: HTML/CSS/JavaScript, React/Next.js, Python, C/C++, Java/Kotlin, C#/.NET and Unity first; modular runtimes later.
- Offline-capable interface and planned offline model runtime; optional free cloud models; no mandatory API keys; never silently use paid services.
- Local autosave/checkpoints, optional encrypted cloud backup/sync, conflict handling, export/import and permanent deletion.
- Secret scanning, dependency vulnerability checks, Android permission review, backend/auth/database checks, isolated workers and security gates before public deployment.
- One-tap deploy after preview/approval; HTTPS, environment variables, deployment history, smoke tests and rollback where provider supports it.
- APK debug/release variants, secure release-signing guide and optional AAB. Real APK compilation requires Android SDK/Gradle tooling.

## Phased implementation
1. **Local prototype:** responsive dashboard, local project CRUD, blueprint and starter files, file editor, sandboxed HTML preview, JSON backup/import, settings and explicitly simulated build queue.
2. **Workspace foundation (Phase 2 delivered):** IndexedDB persistence with localStorage fallback/migration, folders and folder filtering, soft-delete trash/restore, checkpoint history, undo/restore, and ZIP export plus text-focused ZIP import. A true visual drag-and-drop editor, file-level diff viewer, comprehensive binary-asset handling, automated test suite, and Android device validation remain future work.
3. **AI layer (foundation implemented):** optional Node.js API, server-side OpenAI-compatible provider adapter, optional server-side secret, rate limits/origin checks, local fallback chat/plans, plan draft/review/approval. Offline model runtime/downloads and patch-based AI code edits remain future work.
4. **Phase 4 diagnostics (delivered):** local static preflight checks, bounded job history and clearly labelled demo jobs.
5. **Phase 5 worker foundation (implemented, runtime verification pending):** optional Docker-backed web build queue, request/path/size validation, CPU/memory/PID limits, network disabled by default, logs, cancellation, job removal, and ZIP artifact download. Authentication, multi-tenant isolation and public deployment hardening remain required before internet exposure.
6. **Hosting and native builds (future):** private workspaces, static hosting and backend services, HTTPS, secrets manager, smoke tests, deployment history, rollback, cross-device sync, and Android SDK/Gradle worker.

## Architecture recommendation
- Client: responsive PWA; IndexedDB for project files; service worker for static offline shell.
- Android: thin WebView shell first; audited native bridges only when required.
- API: versioned project/job/artifact API, model-provider abstraction and optional sync service.
- Worker: isolated queue consumers for web and Android builds; never execute untrusted code inside the API process.
- Storage: local database plus optional cloud database/object storage with encryption and access controls.

## Phase 1 acceptance criteria
1. Opens on phone/desktop without login.
2. Create project from a prompt and view blueprint/starter files.
3. Data persists in current browser and exports/imports as JSON.
4. Edit `index.html`, save, and see sandboxed preview update.
5. Search, sort, favorite, duplicate, rename and delete projects.
6. Build UI clearly labels simulation; never claims to compile/deploy real artifacts.
7. No API key, paid service or account is required.

## Honest constraints
This is a client-side prototype. It does not include a live language model, offline model weights, container worker, cloud hosting, cross-device sync, production-secure storage, real drag-and-drop editor, real publishing or APK compilation. Offline UI is not offline AI inference. Hosting and remote builds require infrastructure; free-to-user does not mean unlimited free compute. The Android source in this bundle is a starter and has not been compiled or device-tested here.


## Phase 2 implementation notes
- IndexedDB database: `nova-forge-phase2`, object store `kv`. Existing browser-local data is migrated into it when first opened; localStorage is retained as a fallback.
- ZIP export writes valid ZIP archives using the store method (no compression). Import accepts stored entries and DEFLATE when `DecompressionStream` supports `deflate-raw`; it limits archives to 25 MB and individual text files to 2 MB, skips path traversal and directory entries, and is not intended for arbitrary binary-heavy projects.
- Project versions are capped at 30 snapshots per project; local trash retains up to 100 deleted projects. This is recovery convenience, not encrypted backup.
- The UI has been syntax-checked with Node.js. Browser-specific IndexedDB and ZIP flows should still be exercised on the target Android browser before relying on them.


## Phase 3 implementation notes
- `server/server.js` uses Node.js built-ins only, serves `web/`, and exposes health/chat/plan APIs. It binds to `127.0.0.1` by default.
- Optional model configuration is read from `server/.env` (copy `server/.env.example`) or process environment. The configured provider must implement the OpenAI-compatible `/chat/completions` route.
- The web client stores only the server URL, not the provider key. Remote cross-origin use requires exact frontend origins in `NOVA_ALLOWED_ORIGINS`; remote deployments also require HTTPS, authentication, firewall rules, and production hardening.
- Smoke tests: `cd server && npm run check`. Browser-level interaction testing is still pending because Chromium did not complete a headless run in the build environment.


## Phase 4 implementation notes
- Build & Publish runs local static preflight diagnostics on saved text files and stores a bounded history of results in browser storage.
- Preflight checks cover common browser-entry, metadata, local-reference, image-alt, risky-eval, HTTP-link, oversized-file, TODO/FIXME, and secret-like assignment signals. They do not execute project code and are not a full security or compiler check.
- Demo jobs remain marked as simulations. A real worker should be implemented separately with authentication, isolation, resource limits, cancellation, logs, artifacts, and cleanup.
- `npm run check --prefix server` includes the preflight test suite. Chromium headless testing timed out, so manual browser and Android validation remain pending.


## Phase 5 implementation notes
- `server/build-worker.js` implements a Docker-backed worker for static HTML and Node web projects. The API process validates request shape, relative paths, file count and size limits before queueing work. The worker runs in a separate Docker container with memory/CPU/PID caps, dropped capabilities, no-new-privileges, a read-only root, a writable project mount and no network by default.
- API routes: `GET /api/builds`, `POST /api/builds`, `GET /api/builds/:id`, `GET /api/builds/:id/logs`, `GET /api/builds/:id/artifact`, `POST /api/builds/:id/cancel`, and `DELETE /api/builds/:id`. Queue metadata and artifacts are in memory and do not survive server restart.
- Worker is disabled by default. Enable with `NOVA_BUILD_WORKER_ENABLED=true` only on a trusted private server with Docker available. Network access for builds requires a separate explicit `NOVA_BUILD_ALLOW_NETWORK=true` setting. Do not expose the unauthenticated prototype to the public internet.
- The browser Build & Publish page can submit the selected project's files to the configured server, refresh job state, request cancellation, and download completed ZIP artifacts. This is web build packaging, not Android APK compilation or website deployment.
- Automated tests cover worker request validation, path traversal/secret-file rejection, limits, ZIP structure, and the disabled-by-default API. End-to-end Docker execution could not be tested because Docker is not installed/available in the current environment.


## Phase 6 implementation notes
- Phone-first hosting blueprint: `render.yaml` configures one managed Node service, health checks, a generated access token, and safe static packaging. Deployment must still be authorized by the account owner; no live endpoint is provisioned by the code bundle.
- API access control is optional for local-only development and enabled by setting `NOVA_ACCESS_TOKEN`. Hosted template generates a token. Keep it private; the browser only stores it in session storage.
- Static packaging path does not execute project source, install dependencies, or claim to compile. It accepts an `index.html` project with supported text-oriented asset extensions and returns a ZIP.
- Dynamic npm builds, durable job persistence, multi-user tenant isolation, APK compilation, and publishing are not part of Phase 6. The free-hosting template keeps the Docker worker disabled.
